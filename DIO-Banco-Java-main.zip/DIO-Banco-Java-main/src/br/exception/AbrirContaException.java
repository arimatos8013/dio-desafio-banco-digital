package br.exception;

@SuppressWarnings("serial")
public class AbrirContaException extends Exception {

	public AbrirContaException() {
	}

}
