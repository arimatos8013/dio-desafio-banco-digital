package br.exception;

@SuppressWarnings("serial")
public class ValorInvalidoException extends Exception {

	public ValorInvalidoException() {
	}

}
