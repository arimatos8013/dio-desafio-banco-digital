package br.exception;

@SuppressWarnings("serial")
public class CpfInvalidoException extends Exception {

	public CpfInvalidoException() {
	}

}
